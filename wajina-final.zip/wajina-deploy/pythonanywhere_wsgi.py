# -*- coding: utf-8 -*-
"""
PythonAnywhere WSGI Configuration for Wajina Suite
This file is used by PythonAnywhere to run your Flask application.

Installation:
1. Upload this file to your home directory on PythonAnywhere
2. In PythonAnywhere Web app settings, set the WSGI configuration file path to:
   /home/{username}/{path-to-this-file}/pythonanywhere_wsgi.py
"""

import sys
import os
from pathlib import Path

# Add the project directory to the Python path
# This should point to where app.py is located
project_dir = os.path.dirname(os.path.abspath(__file__))
if project_dir not in sys.path:
    sys.path.insert(0, project_dir)

# Set environment variables for PythonAnywhere
# These can be overridden in PythonAnywhere's Web app settings
os.environ.setdefault('FLASK_ENV', 'production')

# Import the Flask app
try:
    from app import app
    application = app  # WSGI compatible variable name
except ImportError as e:
    print(f"Error importing Flask app: {e}")
    raise

# Ensure database tables are created on first run
with app.app_context():
    try:
        from database import db
        db.create_all()
        print("Database tables initialized successfully")
    except Exception as e:
        print(f"Warning: Could not initialize database: {e}")

# Log that the WSGI app has been loaded
print("Wajina Suite WSGI application loaded successfully on PythonAnywhere")

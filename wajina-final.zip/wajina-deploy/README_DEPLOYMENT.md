# Wajina Suite - Production Deployment

## 🚀 Quick Deploy to Render.com

### Prerequisites
- GitHub account
- Render.com account (free tier available)

### Steps

1. **Push to GitHub:**
   ```bash
   git init
   git add .
   git commit -m "Production ready"
   git remote add origin https://github.com/YOUR_USERNAME/wajina-suite.git
   git push -u origin main
   ```

2. **Deploy on Render:**
   - Go to [render.com](https://render.com)
   - New → Web Service → Connect GitHub repo
   - Build Command: `pip install -r requirements.txt`
   - Start Command: `gunicorn app:app`
   - Add PostgreSQL database
   - Set environment variables (see below)
   - Deploy!

3. **Initialize Database:**
   - Use Render Shell: `python -c "from app import app, db; db.create_all()"`

### Required Environment Variables

```
SECRET_KEY=your-strong-secret-key
FLASK_ENV=production
DATABASE_URL=postgresql://... (from Render PostgreSQL)
```

### Default Login
- Username: `admin`
- Password: `admin123`
- **⚠️ Change immediately after first login!**

---

## 📚 Full Documentation

See `DEPLOY_TO_RENDER.md` for complete step-by-step guide.

---

## 🔧 Local Development

```bash
# Install dependencies
pip install -r requirements.txt

# Run locally
python app.py

# Access at http://localhost:5000
```

---

## 📝 Project Structure

```
Wajina-app/
├── app.py              # Main application
├── routes.py           # All routes
├── models.py           # Database models
├── database.py         # Database config
├── requirements.txt    # Python dependencies
├── Procfile           # Production server config
├── gunicorn_config.py  # Gunicorn settings
└── static/            # Static files
└── templates/         # HTML templates
```

---

## 🆘 Support

- **Deployment Issues**: See `DEPLOY_TO_RENDER.md`
- **Database Setup**: See `POSTGRESQL_SETUP.md`
- **General Help**: See `README.md`


# Fix: Render Build Error - requirements.txt Not Found

## Error Message
```
ERROR: Could not open requirements file: [Errno 2] No such file or directory: 'requirements.txt'
```

## What This Error Means

This error occurs during the Render build process when pip tries to install dependencies but cannot find the `requirements.txt` file. This typically happens because:

1. **The file is not committed to Git** (Most Common - 90% of cases)
2. **The file is in .gitignore** (Rare, but possible)
3. **Repository root directory is misconfigured** on Render
4. **The file has encoding issues** that prevent it from being read
5. **The file is in a subdirectory** instead of the repository root

---

## ✅ Solution 1: Ensure requirements.txt is Committed to Git

### Step 1: Check if file is tracked by Git

```bash
# Check if file exists locally
ls -la requirements.txt

# Check if it's tracked by git (if git is available)
git ls-files requirements.txt

# Check if it's ignored
git check-ignore -v requirements.txt
```

### Step 2: Add and Commit the File

If the file is not committed:

```bash
# Add the file
git add requirements.txt

# Commit it
git commit -m "Add requirements.txt for deployment"

# Push to GitHub
git push
```

### Step 3: Verify on GitHub

1. Go to your GitHub repository
2. Check that `requirements.txt` appears in the file list
3. Click on it to verify the contents are correct

---

## ✅ Solution 2: Check Render Root Directory Setting

1. Go to [Render Dashboard](https://dashboard.render.com)
2. Click on your **Web Service**
3. Go to **Settings** tab
4. Scroll to **"Root Directory"** section
5. **IMPORTANT**: This should be **empty** or set to `/`
6. If it's set to a subdirectory, **clear it** or change to `/`
7. Click **Save Changes**
8. **Manually trigger a new deployment**

---

## ✅ Solution 3: Verify File Location

The `requirements.txt` file **MUST** be in the **root directory** of your repository.

Your repository structure should look like this:

```
wajina-suite/                    ← Repository root
├── app.py                       ← Must be here
├── requirements.txt             ← MUST be here (root level)
├── Procfile                     ← Must be here
├── gunicorn_config.py           ← Must be here
├── runtime.txt                  ← Must be here
├── render.yaml                  ← Must be here
├── routes.py
├── models.py
├── database.py
├── static/
├── templates/
└── ...
```

**If `requirements.txt` is in a subdirectory**, move it to the root:

```bash
# If it's in a subdirectory, move it
mv subdirectory/requirements.txt ./requirements.txt

# Then commit
git add requirements.txt
git commit -m "Move requirements.txt to root directory"
git push
```

---

## ✅ Solution 4: Fix File Encoding Issues

If the file has encoding issues (we detected this earlier), recreate it:

### Option A: Recreate the File

1. **Backup the current file:**
   ```bash
   cp requirements.txt requirements.txt.backup
   ```

2. **Create a new file with proper UTF-8 encoding:**
   ```bash
   # On Windows PowerShell
   [System.IO.File]::WriteAllText("requirements.txt", (Get-Content requirements.txt.backup -Raw), [System.Text.Encoding]::UTF8)
   ```

3. **Or manually copy the contents** from `requirements.txt.backup` into a new `requirements.txt` file

### Option B: Verify File Encoding

The file should be saved as **UTF-8** without BOM. Most text editors allow you to change encoding:
- **VS Code**: Bottom right → Click encoding → Select "UTF-8"
- **Notepad++**: Encoding → Convert to UTF-8
- **Sublime Text**: File → Save with Encoding → UTF-8

---

## ✅ Solution 5: Update Build Command (Temporary Fix)

If the above solutions don't work, you can specify the full path in the build command:

1. Go to Render Dashboard → Your Web Service → **Settings**
2. Find **"Build Command"**
3. Change from:
   ```
   pip install -r requirements.txt
   ```
   To:
   ```
   pip install -r ./requirements.txt
   ```
   Or if using absolute path:
   ```
   pip install -r /opt/render/project/src/requirements.txt
   ```

**Note**: This is usually not necessary if the file is in the root directory.

---

## ✅ Solution 6: Verify File is Not in .gitignore

Check your `.gitignore` file to ensure `requirements.txt` is **NOT** ignored:

```bash
# Check if requirements.txt is ignored
git check-ignore -v requirements.txt
```

If it returns a path, remove that line from `.gitignore`:

```bash
# Remove the ignore rule (if present)
# Edit .gitignore and remove any line containing "requirements.txt"
```

---

## ✅ Solution 7: Manual Verification on Render

After pushing to GitHub, verify the file exists on Render:

1. Go to Render Dashboard → Your Web Service
2. Click **"Shell"** tab
3. Run these commands:
   ```bash
   # List files in root directory
   ls -la
   
   # Check if requirements.txt exists
   ls -la requirements.txt
   
   # View file contents
   cat requirements.txt
   ```

If the file doesn't exist here, it means it wasn't pushed to GitHub.

---

## 🔍 Quick Diagnostic Checklist

Run through this checklist to identify the issue:

- [ ] **File exists locally**: `ls -la requirements.txt` shows the file
- [ ] **File is in root directory**: Not in a subdirectory
- [ ] **File is committed to git**: `git ls-files requirements.txt` shows it
- [ ] **File is pushed to GitHub**: Visible in GitHub repository
- [ ] **File is not in .gitignore**: `git check-ignore -v requirements.txt` returns nothing
- [ ] **Render root directory is empty or `/`**: Checked in Render Settings
- [ ] **File encoding is UTF-8**: No encoding errors when reading
- [ ] **File has content**: Not empty, contains package names

---

## 🚀 After Fixing: Redeploy

Once you've fixed the issue:

### Option A: Manual Deploy
1. Go to Render Dashboard → Your Web Service
2. Click **"Manual Deploy"** → **"Deploy latest commit"**

### Option B: Push New Commit
```bash
# Make a small change to trigger redeploy
git add requirements.txt
git commit -m "Fix: Ensure requirements.txt is properly committed"
git push
```

Render will automatically detect the new commit and redeploy.

---

## 📋 Complete Fix Procedure (Step-by-Step)

1. **Verify file exists locally:**
   ```bash
   ls -la requirements.txt
   ```

2. **Ensure file is in root directory** (not in a subdirectory)

3. **Add file to git** (if not already):
   ```bash
   git add requirements.txt
   ```

4. **Commit the file:**
   ```bash
   git commit -m "Add requirements.txt for deployment"
   ```

5. **Push to GitHub:**
   ```bash
   git push
   ```

6. **Verify on GitHub:**
   - Go to your repository on GitHub
   - Confirm `requirements.txt` is visible in the file list

7. **Check Render Settings:**
   - Root Directory should be empty or `/`
   - Build Command should be: `pip install -r requirements.txt`

8. **Redeploy on Render:**
   - Manual Deploy → Deploy latest commit

---

## 🆘 Still Having Issues?

If none of the above solutions work:

1. **Check Render Build Logs:**
   - Go to your service → **"Logs"** tab
   - Look for the exact error message
   - Check what files are listed in the build directory

2. **Contact Render Support:**
   - They can check if there's an issue with repository connection
   - Provide them with your repository URL and service name

3. **Alternative: Use render.yaml:**
   - The `render.yaml` file should handle this automatically
   - Try using "New Blueprint" deployment instead of manual setup

---

## ✅ Expected Result

After fixing, your build should show:
```
Collecting Flask==3.0.0
Collecting gunicorn==21.2.0
...
Successfully installed Flask-3.0.0 gunicorn-21.2.0 ...
```

Instead of:
```
ERROR: Could not open requirements file: [Errno 2] No such file or directory: 'requirements.txt'
```

---

**Last Updated**: 2024
**Status**: Active Fix Guide


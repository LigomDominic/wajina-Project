# Fixing Render.com Deployment Error

## Error: "Could not open requirements file: [Errno 2] No such file or directory: 'requirements.txt'"

This error occurs when Render can't find the `requirements.txt` file. Here are the solutions:

---

## Solution 1: Ensure requirements.txt is Committed to Git

### Step 1: Check if file is tracked
```bash
git status requirements.txt
```

### Step 2: If not tracked, add and commit it
```bash
git add requirements.txt
git commit -m "Add requirements.txt"
git push
```

### Step 3: Verify it's in the repository
```bash
git ls-files | grep requirements.txt
```

---

## Solution 2: Check Repository Root on Render

1. Go to your Render dashboard
2. Click on your Web Service
3. Go to "Settings"
4. Check "Root Directory" - it should be empty or set to `/`
5. If it's set to a subdirectory, clear it or set to `/`

---

## Solution 3: Verify File is in Root Directory

Make sure `requirements.txt` is in the root of your repository, not in a subdirectory.

Your repository structure should look like:
```
your-repo/
├── app.py
├── requirements.txt  ← Must be here
├── Procfile
├── routes.py
├── models.py
└── ...
```

---

## Solution 4: Update Build Command (If needed)

If your file structure is different, you can specify the full path:

1. Go to Render dashboard → Your Web Service → Settings
2. Update "Build Command" to:
   ```bash
   pip install -r ./requirements.txt
   ```
   Or if in a subdirectory:
   ```bash
   pip install -r /path/to/requirements.txt
   ```

---

## Solution 5: Manual Check - Verify File Exists

### On Render (via Shell):
1. Go to your Web Service on Render
2. Click "Shell"
3. Run:
   ```bash
   ls -la requirements.txt
   cat requirements.txt
   ```

If the file doesn't exist, it wasn't pushed to git.

---

## Solution 6: Re-deploy After Fixing

After ensuring the file is committed:

1. **Option A: Manual Deploy**
   - Go to Render dashboard
   - Click "Manual Deploy" → "Deploy latest commit"

2. **Option B: Push New Commit**
   ```bash
   git add requirements.txt
   git commit -m "Fix: Ensure requirements.txt is committed"
   git push
   ```
   Render will auto-deploy

---

## Quick Fix Checklist

- [ ] `requirements.txt` exists in project root
- [ ] File is committed to git (`git add requirements.txt`)
- [ ] File is pushed to GitHub/GitLab (`git push`)
- [ ] Render repository root is set correctly (empty or `/`)
- [ ] Build command is: `pip install -r requirements.txt`

---

## Still Having Issues?

1. **Check Render Build Logs:**
   - Go to your service → "Logs"
   - Look for the exact error message
   - Check what files are present in the build

2. **Verify Git Repository:**
   ```bash
   git log --oneline --all
   git ls-tree -r HEAD --name-only | grep requirements
   ```

3. **Try Alternative Build Command:**
   ```bash
   pip install Flask==3.0.0 Flask-SQLAlchemy==3.1.1 Flask-Login==0.6.3 Flask-WTF==1.2.1 Flask-Mail==0.10.0 WTForms==3.1.1 Werkzeug==3.0.1 python-dotenv==1.0.0 bcrypt==4.1.2 Pillow==10.1.0 openpyxl==3.1.2 reportlab==4.0.7 qrcode==7.4.2 requests==2.31.0 flask-cors==4.0.0 gunicorn==21.2.0 psycopg2-binary==2.9.9
   ```
   (Not recommended, but works as a temporary fix)

---

## Common Causes

1. **File not committed to git** (Most common)
2. **Repository root misconfigured on Render**
3. **File in wrong directory**
4. **Git ignore rules** (check `.gitignore`)

---

## Verify Your Setup

Run these commands locally to verify:

```bash
# Check file exists
ls -la requirements.txt

# Check it's tracked by git
git ls-files requirements.txt

# Check it's not ignored
git check-ignore -v requirements.txt
# (Should return nothing if not ignored)

# View file contents
cat requirements.txt
```

If all checks pass, the issue is likely on Render's side (repository connection or root directory setting).


# Wajina Suite - PythonAnywhere Deployment Guide

A comprehensive guide to deploy the Wajina Suite school management system on PythonAnywhere.com.

## Table of Contents
1. [Prerequisites](#prerequisites)
2. [PythonAnywhere Account Setup](#pythonanywhere-account-setup)
3. [Step-by-Step Deployment](#step-by-step-deployment)
4. [Configuration & Environment Variables](#configuration--environment-variables)
5. [Database Setup](#database-setup)
6. [Static Files & Media](#static-files--media)
7. [Email Configuration](#email-configuration)
8. [Troubleshooting](#troubleshooting)

---

## Prerequisites

- A PythonAnywhere account (free or paid) at https://www.pythonanywhere.com
- Git installed on your local machine
- This Wajina Suite project configured and ready to deploy

**Note**: Free PythonAnywhere accounts have limitations:
- Only certain websites are whitelisted (can't send emails directly)
- Limited RAM and CPU
- No scheduled tasks
- Database limited to SQLite

**Recommendation**: Use a paid account for production deployment.

---

## PythonAnywhere Account Setup

### 1. Create Your PythonAnywhere Account

1. Visit https://www.pythonanywhere.com
2. Sign up for an account (Beginner plan is free, or upgrade for production)
3. Confirm your email address
4. Log in to your dashboard

### 2. Set Up Your Domain

**For Paid Accounts:**
- Go to Web → Add a new web app
- Choose "Manual configuration" instead of a framework
- Select Python version 3.11 or newer
- Choose your domain or add a custom domain

**For Free Accounts:**
- You get a free subdomain: `{username}.pythonanywhere.com`

---

## Step-by-Step Deployment

### Step 1: Upload Your Code to PythonAnywhere

#### Using Git (Recommended)

1. In PythonAnywhere Bash console:
```bash
cd ~
git clone https://github.com/yourusername/wajina-deploy.git
cd wajina-deploy
```

Or if it's a private repo:
```bash
git clone https://yourusername:your_github_token@github.com/yourusername/wajina-deploy.git
```

#### Uploading via Web Interface

1. Go to **Files** tab in PythonAnywhere
2. Navigate to your home directory
3. Upload the project folder as a zip file
4. Extract it

### Step 2: Create a Web App

1. Go to **Web** tab
2. Click **Add a new web app**
3. Choose **Manual configuration**
4. Select **Python 3.11** (or your preferred version)
5. This will create a default WSGI file at `/var/www/{username}_pythonanywhere_com_wsgi.py`

### Step 3: Replace WSGI Configuration

1. In **Web** → Your web app → **Code** section
2. Click on the WSGI configuration file path to edit it
3. Replace the entire content with:

```python
# -*- coding: utf-8 -*-
import sys
import os

# Add project directory to Python path
project_home = u'/home/{username}/wajina-deploy'
if project_home not in sys.path:
    sys.path.insert(0, project_home)

# Load environment variables from .env file
os.chdir(project_home)
from dotenv import load_dotenv
load_dotenv(os.path.join(project_home, '.env'))

# Import and run the Flask app
from app import app as application
```

**Replace `{username}` with your actual PythonAnywhere username**

### Step 4: Create Virtual Environment

1. Go to **Web** tab
2. Find **Virtualenv** section
3. Click **Add a new virtualenv**
4. Choose Python 3.11
5. Once created, click on it to activate

### Step 5: Install Dependencies

In PythonAnywhere Bash console:

```bash
# Navigate to your project
cd ~/wajina-deploy

# Activate the virtual environment
source /home/{username}/.virtualenvs/wajina-deploy/bin/activate

# Install requirements
pip install -r requirements.txt
```

**Important**: Make sure you're installing in the virtualenv, not the system Python.

### Step 6: Configure Static Files

1. In **Web** tab → **Static files** section
2. Add the static file mappings:

| URL | Directory |
|-----|-----------|
| `/static/` | `/home/{username}/wajina-deploy/static/` |
| `/uploads/` | `/home/{username}/wajina-deploy/static/uploads/` |

3. Click **Reload web app** after saving

---

## Configuration & Environment Variables

### Step 1: Create `.env` File

In PythonAnywhere Bash console:

```bash
cd ~/wajina-deploy
nano .env
```

Add the following (update values as needed):

```env
# Flask Configuration
FLASK_ENV=production
SECRET_KEY=your-secret-key-here-change-this-to-something-secure

# Database (PythonAnywhere default - using SQLite)
DATABASE_URL=sqlite:////home/{username}/wajina-deploy/instance/wajina_suite.db

# Email Configuration (Gmail example)
MAIL_SERVER=smtp.gmail.com
MAIL_PORT=587
MAIL_USE_TLS=True
MAIL_USERNAME=your-email@gmail.com
MAIL_PASSWORD=your-app-specific-password

# School Information
SCHOOL_NAME=Wajina International School
SCHOOL_ADDRESS=Makurdi, Benue State, Nigeria
SCHOOL_PHONE=+234-xxx-xxx-xxxx
SCHOOL_EMAIL=admin@wajina.edu.ng

# Flutterwave Payment Gateway (optional)
FLUTTERWAVE_PUBLIC_KEY=your-public-key-here
FLUTTERWAVE_SECRET_KEY=your-secret-key-here
FLUTTERWAVE_ENCRYPTION_KEY=your-encryption-key-here
FLUTTERWAVE_ENVIRONMENT=sandbox

# Security Settings
MIN_PASSWORD_LENGTH=8
SESSION_TIMEOUT_MINUTES=60
MAX_LOGIN_ATTEMPTS=5
```

Press `Ctrl+O` to save, then `Ctrl+X` to exit.

### Step 2: Generate Secure SECRET_KEY

In Bash:

```bash
python3 -c "import secrets; print(secrets.token_hex(32))"
```

Copy the output and update the SECRET_KEY in your `.env` file.

### Step 3: Create Instance Directory

```bash
mkdir -p ~/wajina-deploy/instance
chmod 755 ~/wajina-deploy/instance
```

### Step 4: Create Upload Directories

```bash
mkdir -p ~/wajina-deploy/static/uploads/{documents,profiles,passports,logo,login,receipts}
chmod 755 ~/wajina-deploy/static/uploads -R
```

---

## Database Setup

### Option 1: Using SQLite (Default)

The app uses SQLite by default. The database file will be created automatically at:
```
/home/{username}/wajina-deploy/instance/wajina_suite.db
```

### Option 2: Using PostgreSQL (Recommended for Production)

1. Go to **Databases** tab in PythonAnywhere (Paid accounts only)
2. Create a new PostgreSQL database
3. Note the connection string
4. Update `.env` with:
```env
DATABASE_URL=postgresql://{username}:{password}@{hostname}/{database_name}
```

5. Install PostgreSQL driver:
```bash
pip install psycopg2-binary
```

### Initialize Database

In Bash console:

```bash
cd ~/wajina-deploy
source /home/{username}/.virtualenvs/wajina-deploy/bin/activate
python3 << EOF
from app import app, db
with app.app_context():
    db.create_all()
    print("Database tables created successfully!")
EOF
```

### Create Default Admin User

```bash
python3 << EOF
from app import app, db
from models import User
from werkzeug.security import generate_password_hash

with app.app_context():
    admin = User.query.filter_by(username='admin').first()
    if not admin:
        admin = User(
            username='admin',
            email='admin@wajina.edu.ng',
            password_hash=generate_password_hash('admin123'),
            role='admin',
            first_name='System',
            last_name='Administrator'
        )
        db.session.add(admin)
        db.session.commit()
        print("✓ Admin user created!")
        print("  Username: admin")
        print("  Password: admin123")
        print("  ⚠️  CHANGE THIS PASSWORD IMMEDIATELY AFTER LOGIN!")
EOF
```

---

## Static Files & Media

### Ensure Proper Permissions

```bash
# Give write permissions for uploads
chmod 775 ~/wajina-deploy/static/uploads -R

# Ensure instance directory is writable
chmod 775 ~/wajina-deploy/instance
```

### Configure in Web App Settings

1. Go to **Web** tab
2. Scroll to **Static files** section
3. Verify both mappings exist:
   - `/static/` → `/home/{username}/wajina-deploy/static/`
   - `/uploads/` → `/home/{username}/wajina-deploy/static/uploads/`

4. Click **Reload web app**

---

## Email Configuration

### Using Gmail SMTP (Recommended)

#### Generate App Password

1. Go to https://myaccount.google.com/security
2. Enable 2-Step Verification if not already enabled
3. Go to **App passwords**
4. Select "Mail" and "Windows Computer"
5. Generate a 16-character app password
6. Copy it (note the spaces)

#### Update .env

```env
MAIL_SERVER=smtp.gmail.com
MAIL_PORT=587
MAIL_USE_TLS=True
MAIL_USERNAME=your-email@gmail.com
MAIL_PASSWORD=your-app-specific-password
MAIL_DEFAULT_SENDER=noreply@wajina.edu.ng
```

### Important: Free Account Limitation

**Free PythonAnywhere accounts cannot send emails directly.** If you need email functionality:
- Upgrade to a paid account, OR
- Use a third-party email service (SendGrid, Mailgun, AWS SES)

### Using SendGrid (Works with Free Accounts)

1. Sign up at https://sendgrid.com
2. Get your API key
3. Update `.env`:
```env
MAIL_SERVER=smtp.sendgrid.net
MAIL_PORT=587
MAIL_USE_TLS=True
MAIL_USERNAME=apikey
MAIL_PASSWORD=your-sendgrid-api-key
MAIL_DEFAULT_SENDER=noreply@yourdomain.com
```

---

## Final Steps

### 1. Reload Web App

In PythonAnywhere **Web** tab, click **Reload** button next to your web app.

### 2. Test Your Application

1. Visit `https://{username}.pythonanywhere.com`
2. You should see the Wajina Suite login page
3. Log in with:
   - Username: `admin`
   - Password: `admin123`

### 3. Change Admin Password

1. Log in with admin account
2. Go to **Profile** → **Settings**
3. Change the password immediately

### 4. Configure School Settings

1. Log in as admin
2. Go to **Settings**
3. Update:
   - School name
   - School address
   - School phone
   - School email
   - Logo upload
   - Payment gateway keys

---

## Performance Optimization

### Increase Worker Processes (Paid Accounts)

Edit `/home/{username}/wajina-deploy/gunicorn_config.py`:

```python
workers = 4  # Increase if you have more CPU cores
```

### Enable Caching

Add to your Flask app:

```python
from flask_caching import Cache

cache = Cache(app, config={'CACHE_TYPE': 'simple'})
```

### Database Optimization

For PostgreSQL:
```bash
pip install psycopg2-binary
```

---

## Troubleshooting

### Issue: "502 Bad Gateway"

**Check error logs:**
```bash
cat /var/log/pythonanywhere.com/{username}_pythonanywhere_com_wsgi_error_log.log
```

**Common causes:**
- Missing dependencies: Re-run `pip install -r requirements.txt`
- Wrong WSGI path: Verify path in Web settings
- Database connection issue: Check DATABASE_URL in .env
- Module import error: Check for circular imports in your code

### Issue: Database File Not Found

```bash
# Create and initialize database
cd ~/wajina-deploy
mkdir -p instance
python3 << EOF
from app import app, db
with app.app_context():
    db.create_all()
EOF
```

### Issue: Static Files Not Loading

```bash
# Verify static file mapping in Web settings
# Then reload:
touch /var/www/{username}_pythonanywhere_com_wsgi.py
```

### Issue: Upload Directory Permission Denied

```bash
chmod 775 ~/wajina-deploy/static/uploads -R
```

### Issue: Can't Send Emails (Free Account)

You need a paid account or must use an external email service like SendGrid.

### Issue: Slow Performance

1. Check available RAM and CPU in PythonAnywhere dashboard
2. Reduce `workers` setting in gunicorn_config.py
3. Consider upgrading to a better plan
4. Enable caching for frequently accessed data

### Clear Cache and Reload

```bash
# Restart the web app
touch /var/www/{username}_pythonanywhere_com_wsgi.py
```

---

## Useful PythonAnywhere Commands

### SSH Access (Paid Accounts)

```bash
# Connect via SSH
ssh {username}@ssh.pythonanywhere.com
```

### Scheduled Tasks (Paid Accounts)

Set up backup or cleanup tasks in **Tasks** tab.

### Database Backup

```bash
# Backup SQLite database
cp ~/wajina-deploy/instance/wajina_suite.db ~/wajina-deploy/instance/wajina_suite.db.backup
```

### View Web App Logs

```bash
# Error log
tail /var/log/pythonanywhere.com/{username}_pythonanywhere_com_wsgi_error_log.log

# Access log
tail /var/log/pythonanywhere.com/{username}_pythonanywhere_com_wsgi_access_log.log
```

---

## Important Security Notes

### 1. Change Default Credentials

**IMMEDIATELY** after first login:
- Change admin password
- Disable default admin user if you create a new one

### 2. Update Secrets

```bash
# Generate new SECRET_KEY
python3 -c "import secrets; print(secrets.token_hex(32))"
```

### 3. Enable HTTPS

PythonAnywhere automatically provides free HTTPS certificates. Ensure all links use `https://`.

### 4. Restrict Admin Panel

Configure firewall rules if available in your plan.

### 5. Regularly Update Dependencies

```bash
pip list --outdated
pip install --upgrade {package-name}
```

---

## Additional Resources

- **PythonAnywhere Documentation**: https://help.pythonanywhere.com
- **Flask Documentation**: https://flask.palletsprojects.com
- **SQLAlchemy Documentation**: https://docs.sqlalchemy.org
- **PythonAnywhere File Reference**: https://help.pythonanywhere.com/pages/FileReference

---

## Support

For issues with:
- **PythonAnywhere Platform**: https://help.pythonanywhere.com
- **Wajina Suite Application**: Check the main README.md
- **Flask/Python**: Stack Overflow with `[flask]` or `[python]` tags

---

**Last Updated**: November 2024
**Compatible With**: Python 3.11+, Flask 3.0+

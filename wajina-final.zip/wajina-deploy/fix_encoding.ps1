# PowerShell Script to Fix File Encoding Issues
# Converts requirements.txt from UTF-16 to UTF-8

Write-Host "========================================" -ForegroundColor Cyan
Write-Host "File Encoding Fixer" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""

$file = "requirements.txt"

if (-not (Test-Path $file)) {
    Write-Host "[ERROR] $file not found!" -ForegroundColor Red
    exit 1
}

Write-Host "Checking encoding of $file..." -ForegroundColor Yellow

# Check current encoding
$bytes = [System.IO.File]::ReadAllBytes((Resolve-Path $file))
$isUTF16 = ($bytes[0] -eq 0xFF -and $bytes[1] -eq 0xFE) -or ($bytes[0] -eq 0xFE -and $bytes[1] -eq 0xFF)

if ($isUTF16) {
    Write-Host "[DETECTED] File is UTF-16 encoded" -ForegroundColor Yellow
    Write-Host "[FIXING] Converting to UTF-8..." -ForegroundColor Yellow
    
    # Read as UTF-16
    $content = [System.IO.File]::ReadAllText((Resolve-Path $file), [System.Text.Encoding]::Unicode)
    
    # Write as UTF-8 (without BOM)
    $utf8NoBom = New-Object System.Text.UTF8Encoding $false
    [System.IO.File]::WriteAllText((Resolve-Path $file), $content, $utf8NoBom)
    
    Write-Host "[SUCCESS] File converted to UTF-8!" -ForegroundColor Green
    
    # Verify
    $newBytes = [System.IO.File]::ReadAllBytes((Resolve-Path $file))
    $stillUTF16 = ($newBytes[0] -eq 0xFF -and $newBytes[1] -eq 0xFE) -or ($newBytes[0] -eq 0xFE -and $newBytes[1] -eq 0xFF)
    
    if (-not $stillUTF16) {
        Write-Host "[VERIFIED] File is now UTF-8 encoded" -ForegroundColor Green
    } else {
        Write-Host "[WARNING] Conversion may have failed" -ForegroundColor Yellow
    }
} else {
    Write-Host "[OK] File is already UTF-8 (or compatible)" -ForegroundColor Green
}

Write-Host ""
Write-Host "========================================" -ForegroundColor Cyan
Write-Host "Done!" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan


# Wajina Suite - School Management System

A comprehensive, modern school management system designed specifically for **Wajina International School, Makurdi**, tailored to the Nigerian curriculum and educational processes.

## Features

### Core Modules

- **Learner Management**: Complete learner profiles with Nigerian-specific fields (State of Origin, LGA, etc.)
- **Staff Management**: Comprehensive staff/teacher management with qualifications and designations
- **Attendance Tracking**: Daily attendance marking and monitoring
- **Fee Management**: Tuition and other fees tracking with payment status
- **Examination Management**: Support for WAEC, NECO, JAMB, and internal examinations
- **Class Management**: Class organization with class teachers
- **Academic Records**: Term-by-term academic performance tracking
- **Reports & Analytics**: Comprehensive reporting system

### Nigerian Curriculum Support

- **Examination Types**: WAEC, NECO, JAMB, UTME, Mock Examinations
- **Grading System**: Nigerian grading system (A, B, C, D, F)
- **Academic Terms**: First Term, Second Term, Third Term
- **Learner Information**: State of Origin, LGA (Local Government Area)
- **Fee Types**: Tuition, PTA Levy, Library, Laboratory, Sports, Examination, Development Levy

### User Roles

- **Admin**: Full system access
- **Teacher**: Learner management, attendance, exams, fees
- **Learner**: View own profile, attendance, results, fees
- **Parent**: (Future implementation)

## Technology Stack

- **Backend**: Python 3.8+ with Flask
- **Database**: SQLite (can be upgraded to PostgreSQL/MySQL)
- **Frontend**: HTML5, CSS3, JavaScript, Bootstrap 5
- **Authentication**: Flask-Login with role-based access control

## Installation & Setup

### Prerequisites

- Python 3.8 or higher
- pip (Python package manager)

### Step 1: Clone or Download the Project

```bash
cd Wajina-app
```

### Step 2: Create Virtual Environment (Recommended)

**Windows:**
```bash
python -m venv venv
venv\Scripts\activate
```

**Linux/Mac:**
```bash
python3 -m venv venv
source venv/bin/activate
```

### Step 3: Install Dependencies

```bash
pip install -r requirements.txt
```

### Step 4: Run the Application

```bash
python app.py
```

The application will start on `http://localhost:5000`

### Step 5: Login

**Default Admin Credentials:**
- Username: `admin`
- Password: `admin123`

**Important**: Change the default admin password after first login!

## Project Structure

```
Wajina-app/
├── app.py                 # Main Flask application
├── models.py              # Database models
├── routes.py              # Application routes
├── requirements.txt       # Python dependencies
├── README.md             # This file
├── templates/            # HTML templates
│   ├── auth/             # Authentication templates
│   ├── learners/         # Learner management templates
│   ├── staff/            # Staff management templates
│   ├── attendance/       # Attendance templates
│   ├── fees/             # Fee management templates
│   ├── exams/            # Examination templates
│   ├── classes/          # Class management templates
│   ├── reports/          # Reports templates
│   ├── base.html         # Base template
│   └── dashboard.html    # Dashboard template
├── static/               # Static files
│   ├── css/              # Stylesheets
│   ├── js/               # JavaScript files
│   └── images/          # Images
└── wajina_suite.db       # SQLite database (created automatically)
```

## Usage Guide

### Adding Learners

1. Navigate to **Learners** → **Add Learner**
2. Fill in all required information
3. Include Nigerian-specific details (State of Origin, LGA)
4. Set admission number and class
5. Save

### Marking Attendance

1. Go to **Attendance** → **Mark Attendance**
2. Select date and class
3. Mark each learner as Present, Absent, Late, or Excused
4. Add remarks if needed
5. Save attendance

### Managing Fees

1. Navigate to **Fees** → **Add Fee**
2. Select learner and fee type
3. Enter amount and due date
4. Select session and term
5. When payment is received, click **Mark Paid** and enter payment details

### Creating Examinations

1. Go to **Exams** → **Create Exam**
2. Enter exam details (name, type, class, subject)
3. Select exam type (Internal, WAEC, NECO, JAMB, etc.)
4. Set maximum score
5. After exam, enter results for each learner

### Entering Exam Results

1. Navigate to **Exams** → Select exam → **Enter Results**
2. Enter scores for each learner
3. Grades and remarks are calculated automatically based on Nigerian grading system
4. Save results

## Design Theme

- **Primary Color**: Lemon Green (#9ACD32)
- **Fonts**: 
  - Primary: Inter (for body text)
  - Headings: Poppins (for titles and headings)
- **Modern UI**: Clean, responsive design with smooth animations

## Database

The application uses SQLite by default. To upgrade to PostgreSQL or MySQL:

1. Update `SQLALCHEMY_DATABASE_URI` in `app.py`
2. Example for PostgreSQL:
   ```python
   app.config['SQLALCHEMY_DATABASE_URI'] = 'postgresql://user:password@localhost/wajina_suite'
   ```

## Security Notes

- Change default admin password immediately
- Use environment variables for sensitive configuration
- Implement HTTPS in production
- Regular database backups recommended

## Future Enhancements

- Parent portal access
- SMS notifications
- Email notifications
- Advanced analytics and charts
- Report card generation (PDF)
- Bulk operations (import/export)
- Mobile app integration
- Online payment integration

## Support

For issues, questions, or contributions, please contact the development team.

## License

This project is developed for Wajina International School, Makurdi.

---

**Wajina Suite** - Empowering Education Management in Nigeria


// Offline Handler - Register service worker and handle offline status
(function() {
    'use strict';

    // Check if service workers are supported
    if ('serviceWorker' in navigator) {
        // Register service worker
        window.addEventListener('load', () => {
            navigator.serviceWorker.register('/static/js/service-worker.js')
                .then((registration) => {
                    console.log('Service Worker registered successfully:', registration.scope);
                    
                    // Check for updates
                    registration.addEventListener('updatefound', () => {
                        const newWorker = registration.installing;
                        newWorker.addEventListener('statechange', () => {
                            if (newWorker.state === 'installed' && navigator.serviceWorker.controller) {
                                // New service worker available
                                showUpdateNotification();
                            }
                        });
                    });
                })
                .catch((error) => {
                    console.log('Service Worker registration failed:', error);
                });
        });

        // Listen for service worker updates
        let refreshing = false;
        navigator.serviceWorker.addEventListener('controllerchange', () => {
            if (!refreshing) {
                refreshing = true;
                window.location.reload();
            }
        });
    }

    // Monitor online/offline status
    function updateOnlineStatus() {
        const isOnline = navigator.onLine;
        const statusIndicator = document.getElementById('offline-indicator');
        
        if (statusIndicator) {
            if (isOnline) {
                statusIndicator.classList.remove('show');
                statusIndicator.classList.add('hide');
            } else {
                statusIndicator.classList.remove('hide');
                statusIndicator.classList.add('show');
            }
        }

        // Update page content if needed
        if (!isOnline) {
            document.body.classList.add('offline-mode');
        } else {
            document.body.classList.remove('offline-mode');
        }
    }

    // Listen for online/offline events
    window.addEventListener('online', () => {
        updateOnlineStatus();
        showMessage('Connection restored', 'success');
        // Try to sync any pending data
        if ('serviceWorker' in navigator && navigator.serviceWorker.controller) {
            navigator.serviceWorker.controller.postMessage({ type: 'SYNC' });
        }
    });

    window.addEventListener('offline', () => {
        updateOnlineStatus();
        showMessage('You are currently offline. Some features may be limited.', 'warning');
    });

    // Initial status check
    updateOnlineStatus();

    // Show update notification
    function showUpdateNotification() {
        const notification = document.createElement('div');
        notification.className = 'alert alert-info alert-dismissible fade show position-fixed top-0 start-50 translate-middle-x mt-3';
        notification.style.zIndex = '9999';
        notification.style.maxWidth = '500px';
        notification.innerHTML = `
            <i class="fas fa-sync-alt"></i> A new version is available!
            <button type="button" class="btn btn-sm btn-primary ms-2" onclick="window.location.reload()">
                Update Now
            </button>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        `;
        document.body.appendChild(notification);
    }

    // Show message function
    function showMessage(message, type = 'info') {
        const alertDiv = document.createElement('div');
        alertDiv.className = `alert alert-${type} alert-dismissible fade show position-fixed top-0 start-50 translate-middle-x mt-3`;
        alertDiv.style.zIndex = '9999';
        alertDiv.style.maxWidth = '500px';
        alertDiv.innerHTML = `
            <i class="fas fa-${type === 'success' ? 'check-circle' : 'exclamation-triangle'}"></i> ${message}
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        `;
        document.body.appendChild(alertDiv);
        
        // Auto-dismiss after 5 seconds
        setTimeout(() => {
            alertDiv.remove();
        }, 5000);
    }

    // Queue form submissions when offline
    function queueFormSubmission(formData, url, method = 'POST') {
        if (!navigator.onLine) {
            // Store in IndexedDB or localStorage
            const pendingSubmissions = JSON.parse(localStorage.getItem('pendingSubmissions') || '[]');
            pendingSubmissions.push({
                url: url,
                method: method,
                data: formData,
                timestamp: Date.now()
            });
            localStorage.setItem('pendingSubmissions', JSON.stringify(pendingSubmissions));
            
            showMessage('Form saved. Will be submitted when connection is restored.', 'info');
            return true;
        }
        return false;
    }

    // Expose queue function globally
    window.queueFormSubmission = queueFormSubmission;

    // Sync pending submissions when back online
    window.addEventListener('online', () => {
        const pendingSubmissions = JSON.parse(localStorage.getItem('pendingSubmissions') || '[]');
        if (pendingSubmissions.length > 0) {
            showMessage(`Syncing ${pendingSubmissions.length} pending submission(s)...`, 'info');
            // Process submissions (implement based on your needs)
            // This is a placeholder - you'll need to implement actual submission logic
        }
    });
})();


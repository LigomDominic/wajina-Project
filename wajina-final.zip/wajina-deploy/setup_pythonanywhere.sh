#!/bin/bash
# PythonAnywhere Setup Script for Wajina Suite
# This script automates the initial setup process on PythonAnywhere
# Run this in PythonAnywhere Bash Console after uploading the project

set -e  # Exit on error

# Color output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

echo -e "${BLUE}========================================${NC}"
echo -e "${BLUE}Wajina Suite - PythonAnywhere Setup${NC}"
echo -e "${BLUE}========================================${NC}\n"

# Detect username
USERNAME=$(whoami)
PROJECT_DIR="$HOME/wajina-deploy"

echo -e "${YELLOW}[1/8]${NC} Checking project directory..."
if [ -d "$PROJECT_DIR" ]; then
    echo -e "${GREEN}✓ Project directory found: $PROJECT_DIR${NC}"
else
    echo -e "${RED}✗ Project directory not found!${NC}"
    echo "Please upload/clone the wajina-deploy project first."
    exit 1
fi

# Change to project directory
cd "$PROJECT_DIR"

echo -e "\n${YELLOW}[2/8]${NC} Creating virtual environment..."
if [ ! -d "$HOME/.virtualenvs/wajina-deploy" ]; then
    python3 -m venv "$HOME/.virtualenvs/wajina-deploy"
    echo -e "${GREEN}✓ Virtual environment created${NC}"
else
    echo -e "${GREEN}✓ Virtual environment already exists${NC}"
fi

echo -e "\n${YELLOW}[3/8]${NC} Activating virtual environment and installing dependencies..."
source "$HOME/.virtualenvs/wajina-deploy/bin/activate"
pip install --upgrade pip setuptools wheel
pip install -r requirements.txt
echo -e "${GREEN}✓ Dependencies installed${NC}"

echo -e "\n${YELLOW}[4/8]${NC} Creating instance directory..."
mkdir -p "$PROJECT_DIR/instance"
echo -e "${GREEN}✓ Instance directory created${NC}"

echo -e "\n${YELLOW}[5/8]${NC} Creating upload directories..."
mkdir -p "$PROJECT_DIR/static/uploads/{documents,profiles,passports,logo,login,receipts}"
echo -e "${GREEN}✓ Upload directories created${NC}"

echo -e "\n${YELLOW}[6/8]${NC} Setting permissions..."
chmod 755 "$PROJECT_DIR/instance"
chmod 755 "$PROJECT_DIR/static/uploads" -R
echo -e "${GREEN}✓ Permissions set${NC}"

echo -e "\n${YELLOW}[7/8]${NC} Initializing database..."
python3 << 'EOF'
import sys
sys.path.insert(0, '/home/'"$USERNAME"'/wajina-deploy')

from app import app, db
from werkzeug.security import generate_password_hash

try:
    with app.app_context():
        # Create all tables
        db.create_all()
        print("✓ Database tables created")
        
        # Check if admin user exists
        from models import User
        admin = User.query.filter_by(username='admin').first()
        
        if not admin:
            admin = User(
                username='admin',
                email='admin@wajina.edu.ng',
                password_hash=generate_password_hash('admin123'),
                role='admin',
                first_name='System',
                last_name='Administrator'
            )
            db.session.add(admin)
            db.session.commit()
            print("✓ Admin user created")
            print("  Username: admin")
            print("  Password: admin123")
            print("  ⚠️  CHANGE PASSWORD AFTER FIRST LOGIN!")
        else:
            print("✓ Admin user already exists")
except Exception as e:
    print(f"✗ Database initialization failed: {e}")
    sys.exit(1)
EOF

echo -e "\n${YELLOW}[8/8]${NC} Creating .env template..."
if [ ! -f "$PROJECT_DIR/.env" ]; then
    cat > "$PROJECT_DIR/.env" << 'ENVFILE'
# Flask Configuration
FLASK_ENV=production
SECRET_KEY=change-this-to-a-secure-random-key

# Database
DATABASE_URL=sqlite:///instance/wajina_suite.db

# Email Configuration
MAIL_SERVER=smtp.gmail.com
MAIL_PORT=587
MAIL_USE_TLS=True
MAIL_USERNAME=your-email@gmail.com
MAIL_PASSWORD=your-app-password

# School Information
SCHOOL_NAME=Wajina International School
SCHOOL_ADDRESS=Makurdi, Benue State, Nigeria
SCHOOL_PHONE=
SCHOOL_EMAIL=admin@wajina.edu.ng

# Flutterwave (Optional)
FLUTTERWAVE_PUBLIC_KEY=
FLUTTERWAVE_SECRET_KEY=
FLUTTERWAVE_ENCRYPTION_KEY=
FLUTTERWAVE_ENVIRONMENT=sandbox

# Security
MIN_PASSWORD_LENGTH=8
SESSION_TIMEOUT_MINUTES=60
MAX_LOGIN_ATTEMPTS=5
ENVFILE
    echo -e "${GREEN}✓ .env template created (update with your values)${NC}"
else
    echo -e "${GREEN}✓ .env file already exists${NC}"
fi

echo -e "\n${BLUE}========================================${NC}"
echo -e "${GREEN}✓ Setup Complete!${NC}"
echo -e "${BLUE}========================================${NC}\n"

echo -e "${YELLOW}Next Steps:${NC}"
echo "1. Update .env file with your configuration:"
echo "   nano $PROJECT_DIR/.env"
echo ""
echo "2. In PythonAnywhere Web app settings:"
echo "   - Set WSGI configuration file to: /home/$USERNAME/wajina-deploy/pythonanywhere_wsgi.py"
echo "   - Set Virtualenv path to: /home/$USERNAME/.virtualenvs/wajina-deploy"
echo "   - Add static file mappings:"
echo "     /static/ → /home/$USERNAME/wajina-deploy/static/"
echo ""
echo "3. Reload your web app in PythonAnywhere"
echo ""
echo "4. Test your application at: https://$USERNAME.pythonanywhere.com"
echo ""
echo -e "${YELLOW}Documentation:${NC}"
echo "See PYTHONANYWHERE_DEPLOYMENT.md for detailed instructions"
echo ""

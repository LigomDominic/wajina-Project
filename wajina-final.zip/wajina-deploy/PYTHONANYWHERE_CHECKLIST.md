# PythonAnywhere Deployment Checklist

A quick reference guide for deploying Wajina Suite to PythonAnywhere.com

## Pre-Deployment (Local Machine)

- [ ] Update all environment variables in `.env` file
- [ ] Test application locally with `python app.py`
- [ ] Verify database initialization works
- [ ] Test user login with admin/admin123
- [ ] Check all file uploads work
- [ ] Test email functionality (if configured)
- [ ] Generate secure SECRET_KEY: `python3 -c "import secrets; print(secrets.token_hex(32))"`

## Account Setup (PythonAnywhere.com)

- [ ] Create PythonAnywhere account at https://www.pythonanywhere.com
- [ ] Confirm email address
- [ ] Log in to PythonAnywhere dashboard
- [ ] Note your username

## Upload Project

- [ ] Clone or upload project to PythonAnywhere:
  ```bash
  git clone https://github.com/yourusername/wajina-deploy.git
  ```
  OR upload as ZIP and extract

## Web App Configuration

- [ ] Go to **Web** tab
- [ ] Click **Add a new web app**
- [ ] Choose **Manual configuration**
- [ ] Select **Python 3.11** (or newer)
- [ ] Note the WSGI configuration file path

## Virtual Environment Setup

- [ ] Go to **Web** tab → **Virtualenv** section
- [ ] Click **Add a new virtualenv**
- [ ] Select **Python 3.11**
- [ ] Wait for creation to complete
- [ ] Note the virtualenv path: `/home/{username}/.virtualenvs/wajina-deploy`

## Install Dependencies

In PythonAnywhere Bash console:

```bash
cd ~/wajina-deploy
source /home/{username}/.virtualenvs/wajina-deploy/bin/activate
pip install --upgrade pip
pip install -r requirements.txt
```

## Create Directories & Set Permissions

```bash
# Create instance directory
mkdir -p ~/wajina-deploy/instance
chmod 755 ~/wajina-deploy/instance

# Create upload directories
mkdir -p ~/wajina-deploy/static/uploads/{documents,profiles,passports,logo,login,receipts}
chmod 755 ~/wajina-deploy/static/uploads -R
```

## Configure Environment Variables

### Option 1: .env File (Recommended)

```bash
cd ~/wajina-deploy
nano .env
```

Add all required variables (see PYTHONANYWHERE_DEPLOYMENT.md for full list):

```env
FLASK_ENV=production
SECRET_KEY=your-generated-secret-key-here
DATABASE_URL=sqlite:///instance/wajina_suite.db
MAIL_SERVER=smtp.sendgrid.net
MAIL_PORT=587
MAIL_USE_TLS=True
MAIL_USERNAME=apikey
MAIL_PASSWORD=your-sendgrid-api-key
SCHOOL_NAME=Wajina International School
SCHOOL_ADDRESS=Makurdi, Benue State, Nigeria
SCHOOL_EMAIL=admin@wajina.edu.ng
```

### Option 2: PythonAnywhere Web App Settings

- [ ] Go to **Web** tab → **Environment variables** section
- [ ] Add each variable from .env file

## Initialize Database

```bash
cd ~/wajina-deploy
source /home/{username}/.virtualenvs/wajina-deploy/bin/activate

python3 << EOF
from app import app, db
with app.app_context():
    db.create_all()
    print("✓ Database created!")
EOF
```

## Create Default Admin User

```bash
python3 << EOF
from app import app, db
from models import User
from werkzeug.security import generate_password_hash

with app.app_context():
    admin = User.query.filter_by(username='admin').first()
    if not admin:
        admin = User(
            username='admin',
            email='admin@wajina.edu.ng',
            password_hash=generate_password_hash('admin123'),
            role='admin',
            first_name='System',
            last_name='Administrator'
        )
        db.session.add(admin)
        db.session.commit()
        print("✓ Admin user created!")
        print("  Username: admin")
        print("  Password: admin123")
EOF
```

## Configure WSGI Application

- [ ] Go to **Web** tab → **Code** section
- [ ] Click on WSGI configuration file path
- [ ] Replace content with:

```python
# -*- coding: utf-8 -*-
import sys
import os

project_home = u'/home/{username}/wajina-deploy'
if project_home not in sys.path:
    sys.path.insert(0, project_home)

os.chdir(project_home)
from dotenv import load_dotenv
load_dotenv(os.path.join(project_home, '.env'))

from app import app as application
```

**Replace `{username}` with your actual PythonAnywhere username**

## Configure Static Files

- [ ] Go to **Web** tab → **Static files** section
- [ ] Add mapping:
  - URL: `/static/`
  - Directory: `/home/{username}/wajina-deploy/static/`
- [ ] Add mapping:
  - URL: `/uploads/`
  - Directory: `/home/{username}/wajina-deploy/static/uploads/`

## Set Web App Source Code

- [ ] Go to **Web** tab → **Code** section
- [ ] Set source code path: `/home/{username}/wajina-deploy`
- [ ] Set working directory: `/home/{username}/wajina-deploy`

## Reload Web App

- [ ] Go to **Web** tab
- [ ] Click **Reload** button next to your web app
- [ ] Wait for reload to complete (usually 10-30 seconds)

## Test Application

- [ ] Visit `https://{username}.pythonanywhere.com`
- [ ] You should see login page
- [ ] Log in with:
  - Username: `admin`
  - Password: `admin123`
- [ ] Verify dashboard loads
- [ ] Test file upload functionality
- [ ] Check static files (CSS, images) load correctly

## Post-Deployment Configuration

### Security - Change Admin Password

- [ ] Log in as admin
- [ ] Go to **Profile** → **Settings**
- [ ] Change password immediately
- [ ] Create new admin account with strong password
- [ ] Disable or change default admin account

### School Settings

- [ ] Go to **Settings**
- [ ] Update school name
- [ ] Update school address
- [ ] Update school phone
- [ ] Update school email
- [ ] Upload school logo
- [ ] Update current session/term
- [ ] Configure grading system
- [ ] Configure fee types

### Payment Gateway (Optional)

- [ ] If using Flutterwave:
  - [ ] Go to **Settings**
  - [ ] Add Flutterwave keys
  - [ ] Test in sandbox mode first

### Email Configuration (Optional)

- [ ] Test email functionality
- [ ] Send test notification to verify SMTP settings
- [ ] Update from email address

## Monitoring & Maintenance

### Check Logs

```bash
# Error log
tail /var/log/pythonanywhere.com/{username}_pythonanywhere_com_wsgi_error_log.log

# Access log  
tail /var/log/pythonanywhere.com/{username}_pythonanywhere_com_wsgi_access_log.log
```

### Regular Backups

```bash
# Backup database
cp ~/wajina-deploy/instance/wajina_suite.db ~/wajina-deploy/instance/wajina_suite.db.backup
```

### Monitor Resources

- [ ] Check RAM usage in PythonAnywhere dashboard
- [ ] Monitor CPU usage
- [ ] Check disk space
- [ ] Consider upgrading if resource limits are exceeded

### Keep Dependencies Updated

```bash
pip list --outdated
pip install --upgrade {package-name}
```

## Common Issues & Solutions

| Issue | Solution |
|-------|----------|
| 502 Bad Gateway | Check error logs; reinstall dependencies; verify WSGI path |
| Static files not loading | Check static file mappings; clear browser cache; reload web app |
| Database not found | Create instance directory; check DATABASE_URL in .env |
| Can't send emails (free account) | Use SendGrid API or upgrade to paid account |
| Import errors | Verify all packages installed in correct virtualenv |
| Permission denied on uploads | Run: `chmod 755 ~/wajina-deploy/static/uploads -R` |

## Need Help?

- **PythonAnywhere Documentation**: https://help.pythonanywhere.com
- **Wajina Suite Guide**: See PYTHONANYWHERE_DEPLOYMENT.md
- **Flask Documentation**: https://flask.palletsprojects.com
- **Common Issues**: Check logs in `/var/log/pythonanywhere.com/`

---

**Quick Links**:
- PythonAnywhere Dashboard: https://www.pythonanywhere.com/user/{username}/
- Application URL: https://{username}.pythonanywhere.com
- Admin Panel: https://{username}.pythonanywhere.com/admin/

---

**Deployed Date**: _________________

**Admin Email**: _________________

**Deployment Notes**: 

_________________________________________________

_________________________________________________

_________________________________________________

"""
Deployment Verification Script
Run this script to verify your project is ready for deployment
"""

import os
import sys

def check_file_exists(filename, required=True):
    """Check if a file exists"""
    exists = os.path.exists(filename)
    status = "✅" if exists else ("❌" if required else "⚠️")
    print(f"{status} {filename} {'(required)' if required else '(optional)'}")
    return exists

def check_file_content(filename, search_string, description):
    """Check if file contains specific content"""
    try:
        with open(filename, 'r', encoding='utf-8') as f:
            content = f.read()
            if search_string in content:
                print(f"✅ {description}")
                return True
            else:
                print(f"❌ {description} - Not found in {filename}")
                return False
    except Exception as e:
        print(f"❌ Error checking {filename}: {e}")
        return False

def main():
    print("=" * 60)
    print("Wajina Suite - Deployment Verification")
    print("=" * 60)
    print()
    
    all_checks_passed = True
    
    # Check required files
    print("📁 Checking Required Files:")
    print("-" * 60)
    required_files = [
        ('app.py', True),
        ('requirements.txt', True),
        ('Procfile', True),
        ('routes.py', True),
        ('models.py', True),
        ('database.py', True),
        ('.gitignore', True),
    ]
    
    for filename, required in required_files:
        if not check_file_exists(filename, required):
            if required:
                all_checks_passed = False
    
    print()
    
    # Check requirements.txt
    print("📦 Checking requirements.txt:")
    print("-" * 60)
    if os.path.exists('requirements.txt'):
        try:
            # Try different encodings
            encodings = ['utf-8', 'utf-8-sig', 'latin-1', 'cp1252']
            requirements = None
            for encoding in encodings:
                try:
                    with open('requirements.txt', 'r', encoding=encoding) as f:
                        requirements = f.read()
                        break
                except UnicodeDecodeError:
                    continue
            
            if requirements:
                required_packages = [
                    ('flask', 'Flask'),
                    ('gunicorn', 'Gunicorn'),
                    ('psycopg2', 'psycopg2 (or psycopg2-binary)'),
                ]
                for package_key, package_display in required_packages:
                    # Check for package name (with or without version, case-insensitive)
                    requirements_lower = requirements.lower()
                    if package_key in requirements_lower:
                        print(f"✅ {package_display} found")
                    else:
                        print(f"⚠️  {package_display} - Check manually (encoding issue)")
            else:
                print("⚠️  Could not read requirements.txt - check encoding")
        except Exception as e:
            print(f"⚠️  Error reading requirements.txt: {e}")
    
    print()
    
    # Check app.py configuration
    print("⚙️  Checking app.py Configuration:")
    print("-" * 60)
    if os.path.exists('app.py'):
        with open('app.py', 'r') as f:
            app_content = f.read()
            
            checks = [
                ('os.environ.get(\'SECRET_KEY\'', 'SECRET_KEY from environment'),
                ('os.environ.get(\'DATABASE_URL\'', 'DATABASE_URL from environment'),
                ('os.environ.get(\'PORT\'', 'PORT from environment'),
                ('FLASK_ENV', 'FLASK_ENV check'),
            ]
            
            for search, description in checks:
                if search in app_content:
                    print(f"✅ {description}")
                else:
                    print(f"⚠️  {description} - May need manual configuration")
    
    print()
    
    # Check Procfile
    print("🚀 Checking Procfile:")
    print("-" * 60)
    if os.path.exists('Procfile'):
        with open('Procfile', 'r') as f:
            procfile = f.read()
            if 'gunicorn' in procfile:
                print("✅ Gunicorn configured")
            else:
                print("❌ Gunicorn not found in Procfile")
                all_checks_passed = False
            if 'app:app' in procfile:
                print("✅ App entry point correct")
            else:
                print("⚠️  App entry point may be incorrect")
    
    print()
    
    # Check .gitignore
    print("🔒 Checking .gitignore:")
    print("-" * 60)
    if os.path.exists('.gitignore'):
        with open('.gitignore', 'r') as f:
            gitignore = f.read()
            sensitive_files = [
                ('.env', 'Environment files'),
                ('*.db', 'Database files'),
                ('instance/', 'Instance folder'),
            ]
            for pattern, description in sensitive_files:
                if pattern in gitignore:
                    print(f"✅ {description} ignored")
                else:
                    print(f"⚠️  {description} may not be ignored")
    
    print()
    
    # Check directory structure
    print("📂 Checking Directory Structure:")
    print("-" * 60)
    required_dirs = [
        ('static', True),
        ('templates', True),
        ('static/css', False),
        ('static/js', False),
    ]
    
    for dirname, required in required_dirs:
        exists = os.path.exists(dirname) and os.path.isdir(dirname)
        status = "✅" if exists else ("❌" if required else "⚠️")
        print(f"{status} {dirname}/ {'(required)' if required else '(optional)'}")
    
    print()
    
    # Final summary
    print("=" * 60)
    if all_checks_passed:
        print("✅ All critical checks passed!")
        print("Your project appears ready for deployment.")
        print()
        print("Next steps:")
        print("1. Push to GitHub: git add . && git commit -m 'Ready for deployment' && git push")
        print("2. Follow DEPLOY_TO_RENDER.md for deployment instructions")
    else:
        print("❌ Some critical checks failed!")
        print("Please fix the issues above before deploying.")
    print("=" * 60)

if __name__ == '__main__':
    main()


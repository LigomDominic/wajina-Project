# PowerShell Script to Check Deployment Files
# Run this before pushing to GitHub to ensure all files are ready

Write-Host "========================================" -ForegroundColor Cyan
Write-Host "Wajina Suite - Deployment File Checker" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""

$allGood = $true

# Check required files
Write-Host "Checking Required Files:" -ForegroundColor Yellow
Write-Host "------------------------" -ForegroundColor Yellow

$requiredFiles = @(
    "app.py",
    "requirements.txt",
    "Procfile",
    "gunicorn_config.py",
    "runtime.txt",
    "routes.py",
    "models.py",
    "database.py"
)

foreach ($file in $requiredFiles) {
    if (Test-Path $file) {
        $size = (Get-Item $file).Length
        Write-Host "  [OK] $file ($size bytes)" -ForegroundColor Green
    } else {
        Write-Host "  [MISSING] $file" -ForegroundColor Red
        $allGood = $false
    }
}

Write-Host ""

# Check requirements.txt specifically
Write-Host "Checking requirements.txt:" -ForegroundColor Yellow
Write-Host "------------------------" -ForegroundColor Yellow

if (Test-Path "requirements.txt") {
    try {
        $content = Get-Content "requirements.txt" -Raw -Encoding UTF8
        $lines = $content -split "`n" | Where-Object { $_.Trim() -ne "" }
        
        Write-Host "  [OK] File exists" -ForegroundColor Green
        Write-Host "  [OK] Contains $($lines.Count) packages" -ForegroundColor Green
        
        # Check for critical packages
        $criticalPackages = @("Flask", "gunicorn", "psycopg2")
        foreach ($pkg in $criticalPackages) {
            if ($content -match $pkg) {
                Write-Host "  [OK] Contains $pkg" -ForegroundColor Green
            } else {
                Write-Host "  [WARNING] Missing $pkg" -ForegroundColor Yellow
            }
        }
        
        # Check file encoding
        $bytes = [System.IO.File]::ReadAllBytes((Resolve-Path "requirements.txt"))
        if ($bytes[0] -eq 0xFF -and $bytes[1] -eq 0xFE) {
            Write-Host "  [WARNING] File is UTF-16 encoded (should be UTF-8)" -ForegroundColor Yellow
            Write-Host "  [FIX] Re-save the file as UTF-8 in your editor" -ForegroundColor Yellow
        }
        
    } catch {
        Write-Host "  [ERROR] Could not read file: $_" -ForegroundColor Red
        $allGood = $false
    }
} else {
    Write-Host "  [ERROR] requirements.txt not found!" -ForegroundColor Red
    $allGood = $false
}

Write-Host ""

# Check directory structure
Write-Host "Checking Directory Structure:" -ForegroundColor Yellow
Write-Host "------------------------" -ForegroundColor Yellow

$requiredDirs = @("static", "templates")
foreach ($dir in $requiredDirs) {
    if (Test-Path $dir -PathType Container) {
        Write-Host "  [OK] $dir/ exists" -ForegroundColor Green
    } else {
        Write-Host "  [MISSING] $dir/ directory" -ForegroundColor Red
        $allGood = $false
    }
}

Write-Host ""

# Check .gitignore
Write-Host "Checking .gitignore:" -ForegroundColor Yellow
Write-Host "------------------------" -ForegroundColor Yellow

if (Test-Path ".gitignore") {
    $gitignore = Get-Content ".gitignore" -Raw
    if ($gitignore -match "requirements\.txt") {
        Write-Host "  [WARNING] requirements.txt is in .gitignore!" -ForegroundColor Red
        Write-Host "  [FIX] Remove requirements.txt from .gitignore" -ForegroundColor Yellow
        $allGood = $false
    } else {
        Write-Host "  [OK] requirements.txt is NOT ignored" -ForegroundColor Green
    }
} else {
    Write-Host "  [WARNING] .gitignore not found" -ForegroundColor Yellow
}

Write-Host ""

# Final summary
Write-Host "========================================" -ForegroundColor Cyan
if ($allGood) {
    Write-Host "Status: READY FOR DEPLOYMENT" -ForegroundColor Green
    Write-Host ""
    Write-Host "Next Steps:" -ForegroundColor Yellow
    Write-Host "1. Commit all files to git" -ForegroundColor White
    Write-Host "2. Push to GitHub" -ForegroundColor White
    Write-Host "3. Deploy on Render.com" -ForegroundColor White
} else {
    Write-Host "Status: ISSUES FOUND - FIX BEFORE DEPLOYING" -ForegroundColor Red
    Write-Host ""
    Write-Host "Please fix the issues above before deploying." -ForegroundColor Yellow
}
Write-Host "========================================" -ForegroundColor Cyan


# 🔧 How to Fix File Encoding Issues (UTF-16 to UTF-8)

## Problem

Your `requirements.txt` file is saved in **UTF-16** encoding instead of **UTF-8**. This causes issues because:
- Most build systems (including Render) expect UTF-8
- UTF-16 files have a BOM (Byte Order Mark) that can cause parsing errors
- Pip and other tools may fail to read UTF-16 files correctly

## ✅ Solution 1: Automatic Fix (PowerShell Script)

I've created a script that automatically fixes the encoding:

```powershell
.\fix_encoding.ps1
```

This script will:
1. Detect if the file is UTF-16
2. Convert it to UTF-8
3. Verify the conversion was successful

---

## ✅ Solution 2: Manual Fix (PowerShell Command)

Run this command in PowerShell:

```powershell
# Read file as UTF-16 and write as UTF-8
$content = [System.IO.File]::ReadAllText("requirements.txt", [System.Text.Encoding]::Unicode)
$utf8NoBom = New-Object System.Text.UTF8Encoding $false
[System.IO.File]::WriteAllText("requirements.txt", $content, $utf8NoBom)
```

---

## ✅ Solution 3: Manual Fix (Python)

Run this Python command:

```bash
python -c "import codecs; content = codecs.open('requirements.txt', 'r', 'utf-16').read(); codecs.open('requirements.txt', 'w', 'utf-8').write(content)"
```

---

## ✅ Solution 4: Using VS Code (Visual Studio Code)

1. Open `requirements.txt` in VS Code
2. Look at the **bottom right corner** of the editor
3. You'll see the current encoding (e.g., "UTF-16 LE")
4. **Click on the encoding** label
5. Select **"Save with Encoding"**
6. Choose **"UTF-8"**
7. Save the file (Ctrl+S)

---

## ✅ Solution 5: Using Notepad++

1. Open `requirements.txt` in Notepad++
2. Go to **Encoding** menu
3. Select **"Convert to UTF-8"** (NOT "Encode in UTF-8")
4. Save the file (Ctrl+S)

---

## ✅ Solution 6: Using Notepad (Windows)

1. Open `requirements.txt` in Notepad
2. Go to **File** → **Save As**
3. In the "Save as type" dropdown, select **"All Files"**
4. In the "Encoding" dropdown at the bottom, select **"UTF-8"**
5. Click **Save**
6. Confirm overwrite if prompted

---

## 🔍 How to Check Current Encoding

### Method 1: PowerShell
```powershell
$bytes = [System.IO.File]::ReadAllBytes("requirements.txt")
if ($bytes[0] -eq 0xFF -and $bytes[1] -eq 0xFE) {
    Write-Host "UTF-16 LE"
} elseif ($bytes[0] -eq 0xFE -and $bytes[1] -eq 0xFF) {
    Write-Host "UTF-16 BE"
} else {
    Write-Host "UTF-8 or other"
}
```

### Method 2: Python
```python
f = open('requirements.txt', 'rb')
bytes = f.read(10)
f.close()
if bytes[:2] == b'\xff\xfe':
    print('UTF-16 LE')
elif bytes[:2] == b'\xfe\xff':
    print('UTF-16 BE')
else:
    print('UTF-8 or other')
```

### Method 3: VS Code
- Look at bottom right corner - shows current encoding

---

## ✅ Verify Fix Worked

After converting, verify the file is now UTF-8:

```powershell
# PowerShell
$bytes = [System.IO.File]::ReadAllBytes("requirements.txt")
if ($bytes[0] -eq 0xFF -and $bytes[1] -eq 0xFE) {
    Write-Host "Still UTF-16 - conversion failed"
} else {
    Write-Host "UTF-8 - conversion successful!"
}
```

Or test if pip can read it:
```bash
pip install -r requirements.txt --dry-run
```

---

## 🚫 How to Prevent This Issue

### 1. Configure Your Editor Default Encoding

**VS Code:**
1. Go to **File** → **Preferences** → **Settings**
2. Search for "files.encoding"
3. Set **"Files: Encoding"** to **"utf8"**
4. Set **"Files: Auto Guess Encoding"** to **false**

**Notepad++:**
1. Go to **Settings** → **Preferences** → **New Document**
2. Set **"Encoding"** to **"UTF-8"**
3. Check **"Apply to opened ANSI files"**

### 2. Always Save New Files as UTF-8

When creating new text files:
- VS Code: Bottom right → Click encoding → Select "UTF-8" → Save
- Notepad++: Encoding → Convert to UTF-8 → Save
- Notepad: Save As → Encoding: UTF-8

### 3. Use the Verification Script

Before committing files, run:
```powershell
.\check_deployment_files.ps1
```

This will warn you about encoding issues.

---

## 📋 Complete Fix Procedure

1. **Detect the issue:**
   ```powershell
   .\check_deployment_files.ps1
   ```

2. **Fix the encoding:**
   ```powershell
   .\fix_encoding.ps1
   ```

3. **Verify the fix:**
   ```bash
   pip install -r requirements.txt --dry-run
   ```

4. **Commit the fixed file:**
   ```bash
   git add requirements.txt
   git commit -m "Fix: Convert requirements.txt to UTF-8 encoding"
   git push
   ```

5. **Redeploy on Render:**
   - Manual Deploy → Deploy latest commit

---

## ⚠️ Important Notes

- **UTF-8 without BOM** is preferred (no byte order mark)
- **UTF-16** files are larger and cause compatibility issues
- Most build systems and tools expect **UTF-8**
- After fixing, always verify the file works with `pip install -r requirements.txt`

---

## ✅ Expected Result

**Before Fix:**
- File encoding: UTF-16 LE
- Build error: "Could not open requirements file"
- File size: Larger (UTF-16 uses 2 bytes per character)

**After Fix:**
- File encoding: UTF-8
- Build success: Dependencies install correctly
- File size: Smaller (UTF-8 uses 1 byte per ASCII character)

---

**Status**: ✅ Fixed
**Last Updated**: 2024


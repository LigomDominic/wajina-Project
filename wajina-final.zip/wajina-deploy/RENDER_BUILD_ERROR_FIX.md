# 🔧 Fix: Render Build Error - requirements.txt Not Found

## ❌ Error Message
```
ERROR: Could not open requirements file: [Errno 2] No such file or directory: 'requirements.txt'
```

## 📖 What This Error Means

This error occurs during Render's build process when pip tries to install your Python dependencies. The build system cannot find the `requirements.txt` file in your repository.

**Common Causes:**
1. ⚠️ **File not committed to Git** (90% of cases)
2. ⚠️ **File not pushed to GitHub**
3. ⚠️ **Repository root directory misconfigured on Render**
4. ⚠️ **File encoding issues** (UTF-16 instead of UTF-8)
5. ⚠️ **File in wrong location** (subdirectory instead of root)

---

## ✅ Quick Fix (Most Common Solution)

### Step 1: Ensure File is Committed to Git

```bash
# Check if file exists
ls -la requirements.txt

# Add to git
git add requirements.txt

# Commit
git commit -m "Add requirements.txt for deployment"

# Push to GitHub
git push
```

### Step 2: Verify on GitHub

1. Go to your GitHub repository
2. Check that `requirements.txt` is visible in the file list
3. Click on it to verify contents

### Step 3: Check Render Settings

1. Go to [Render Dashboard](https://dashboard.render.com)
2. Click your **Web Service** → **Settings**
3. Check **"Root Directory"** - should be **empty** or `/`
4. **Save Changes**

### Step 4: Redeploy

- Click **"Manual Deploy"** → **"Deploy latest commit"**

---

## 🔍 Detailed Solutions

### Solution 1: File Not Committed (Most Common)

**Problem**: The file exists locally but wasn't added to git.

**Fix**:
```bash
# Add file
git add requirements.txt

# Commit
git commit -m "Add requirements.txt"

# Push
git push origin main
```

**Verify**:
- Check GitHub repository - file should be visible
- File should show in `git ls-files requirements.txt`

---

### Solution 2: Repository Root Misconfigured

**Problem**: Render is looking in the wrong directory.

**Fix**:
1. Render Dashboard → Your Service → **Settings**
2. Find **"Root Directory"** field
3. **Clear it** (leave empty) or set to `/`
4. **Save Changes**
5. **Redeploy**

---

### Solution 3: File Encoding Issue

**Problem**: File is saved in UTF-16 or has BOM, causing read errors.

**Fix**:
1. Open `requirements.txt` in your editor
2. **VS Code**: Bottom right → Click encoding → Select "UTF-8"
3. **Notepad++**: Encoding → Convert to UTF-8
4. Save the file
5. Commit and push again

**Or recreate the file**:
```bash
# Backup
cp requirements.txt requirements.txt.backup

# Create new UTF-8 file (PowerShell)
[System.IO.File]::WriteAllText("requirements.txt", (Get-Content requirements.txt.backup -Raw), [System.Text.Encoding]::UTF8)
```

---

### Solution 4: File in Wrong Location

**Problem**: File is in a subdirectory, not repository root.

**Required Structure**:
```
your-repo/
├── app.py
├── requirements.txt  ← MUST be here (root)
├── Procfile
├── routes.py
└── ...
```

**Fix**:
```bash
# If file is in subdirectory, move it
mv subdirectory/requirements.txt ./requirements.txt

# Commit
git add requirements.txt
git commit -m "Move requirements.txt to root"
git push
```

---

### Solution 5: File in .gitignore

**Problem**: File is accidentally ignored by git.

**Check**:
```bash
git check-ignore -v requirements.txt
```

**Fix**: If it returns a path, edit `.gitignore` and remove that line.

---

## 🧪 Verification Steps

Before deploying, verify:

1. ✅ **File exists locally**: `ls -la requirements.txt`
2. ✅ **File is in root directory**: Not in a subdirectory
3. ✅ **File is committed**: `git ls-files requirements.txt` shows it
4. ✅ **File is on GitHub**: Visible in repository
5. ✅ **File not ignored**: `git check-ignore -v requirements.txt` returns nothing
6. ✅ **Render root is empty**: Checked in Render Settings
7. ✅ **File encoding is UTF-8**: No encoding errors

---

## 🚀 After Fixing

1. **Push to GitHub** (if not already done)
2. **Check Render Settings** (root directory)
3. **Manual Deploy** on Render
4. **Monitor Build Logs** - should show:
   ```
   Collecting Flask==3.0.0
   Collecting gunicorn==21.2.0
   ...
   Successfully installed ...
   ```

---

## 📋 Complete Checklist

- [ ] `requirements.txt` exists in project root
- [ ] File is committed to git (`git add requirements.txt`)
- [ ] File is pushed to GitHub (`git push`)
- [ ] File is visible on GitHub repository
- [ ] File is NOT in `.gitignore`
- [ ] Render root directory is empty or `/`
- [ ] Build command is: `pip install -r requirements.txt`
- [ ] File encoding is UTF-8 (not UTF-16)

---

## 🆘 Still Not Working?

1. **Check Render Build Logs**:
   - Go to service → **Logs** tab
   - Look for file listing: `ls -la`
   - See what files are present

2. **Use Render Shell**:
   - Go to service → **Shell** tab
   - Run: `ls -la requirements.txt`
   - If file doesn't exist, it wasn't pushed to GitHub

3. **Alternative Build Command** (temporary):
   ```
   pip install Flask==3.0.0 Flask-SQLAlchemy==3.1.1 gunicorn==21.2.0 psycopg2-binary==2.9.9
   ```
   (Not recommended, but works as temporary fix)

4. **Contact Render Support** with:
   - Repository URL
   - Service name
   - Build log snippet

---

## 📝 Files Updated

I've updated the following files to help prevent this issue:

- ✅ **`render.yaml`** - Updated start command to match Procfile
- ✅ **`FIX_RENDER_REQUIREMENTS_ERROR.md`** - Detailed fix guide
- ✅ **`check_deployment_files.ps1`** - Verification script

---

## ✅ Expected Result

**Before Fix:**
```
ERROR: Could not open requirements file: [Errno 2] No such file or directory: 'requirements.txt'
```

**After Fix:**
```
Collecting Flask==3.0.0
Collecting gunicorn==21.2.0
Collecting psycopg2-binary==2.9.9
...
Successfully installed Flask-3.0.0 gunicorn-21.2.0 psycopg2-binary-2.9.9 ...
```

---

**Status**: ✅ Fix Guide Ready
**Last Updated**: 2024

